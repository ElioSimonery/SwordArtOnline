﻿using UnityEngine;
using System.Collections;

public class SecondParent : MonoBehaviour {
	public GameObject virtualParent;
}

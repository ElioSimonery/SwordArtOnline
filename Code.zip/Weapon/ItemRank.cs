// Rank
public enum ItemRank
{
	NORMAL = 0,
	MAGIC = 1,
	RARE = 2,
	EPIC = 3
}
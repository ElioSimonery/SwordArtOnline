

public interface IWeaponInfo
{
	int Damage { get; set; }
	float Speed{get;set;}
}



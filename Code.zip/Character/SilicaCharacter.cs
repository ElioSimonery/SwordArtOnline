using UnityEngine;

public class SilicaCharacter : RangerCharacterBase
{

}


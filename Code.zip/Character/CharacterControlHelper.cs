using UnityEngine;
using System.Collections;
public class CharacterControlHelper : MonoBehaviour
{
	public ICCharacterBase c;
}



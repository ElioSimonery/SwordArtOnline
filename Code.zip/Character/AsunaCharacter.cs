﻿using UnityEngine;
using System.Collections;

public class AsunaCharacter : MeleeCharacterBase {

}

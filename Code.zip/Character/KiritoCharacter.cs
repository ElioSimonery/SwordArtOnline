using UnityEngine;
using System.Collections;

public class KiritoCharacter : MeleeCharacterBase {

}

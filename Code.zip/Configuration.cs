public class Configuration
{
	public enum LANGUAGE
	{
		KOR = 0,
		ENG = 1
	}

	public static int LanguageSelect = (int)LANGUAGE.KOR;
}